import { Add } from "../addTransaction.js";

export function DataBase(event) {
  Add(event);
  
}
