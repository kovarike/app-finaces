import { Remove } from "./addTransaction.js";
import { SetStorage } from "./base/storage.js";
import CreateElementTrasaction, { ClearTransaction } from "./createElementTransaction.js";
import DataTransaction from "./dataTransaction.js";
import UpdateSaldos from "./updateSaldos.js";



export function init() {

  DataTransaction.forEach( (transaction, index) => {
    const tr = CreateElementTrasaction(transaction, index);
    document.getElementById('rm').addEventListener('click', () => {
      let check = tr.querySelector('.check');
      if (check.checked && parseInt(check.value) === index) {
        Remove(index);
      }
      console.log(index)



  


    });

    return tr
  
  });


  


  SetStorage(DataTransaction);
  UpdateSaldos();


};

export function reload() {
  ClearTransaction();
  init();

};

init();


