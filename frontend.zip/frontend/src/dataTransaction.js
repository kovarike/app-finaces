import { GetStorage } from "./base/storage.js";

const DataTransaction = GetStorage();
export default DataTransaction;






